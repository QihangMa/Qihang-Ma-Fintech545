from setuptools import setup

setup(
    name='RiskLib',
    version='0.7.1',
    description='using for quatitative risk management',
    author='Qihang Ma',
    packages=['RiskLib'],
    install_requires=['pandas','numpy','scipy'],
)