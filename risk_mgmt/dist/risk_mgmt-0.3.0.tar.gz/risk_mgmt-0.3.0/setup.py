from setuptools import setup

setup(
    name='risk_mgmt',
    version='0.3.0',
    description='using for quatitative risk management',
    author='Qihang Ma',
    packages=['risk_mgmt'],
    install_requires=['pandas','numpy'],
)